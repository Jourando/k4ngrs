<?
$d = md5($_GET['str'].'base');
echo $d;
?>
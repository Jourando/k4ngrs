<?php
// если не add | del | edit | list , выдать сообщение о подключении
IF (ISSET($_POST['str'])) {
	$ep=$_POST['str'];
	if (($ep=='add') || ($ep=='del') || ($ep=='edit') || ($ep=='list') || ($ep=='show') || ($ep=='hide')) {
		// показывать таблицу, переданную JSON'ом
		if (FILE_EXISTS('kf.a')) {
			$lines = file('kf.a');
			$r="{";
			for ($i=0; $i<count($lines); $i++) {
				$r=$r.'"tk'.($i+1).'": ['.$lines[$i].']';
				if ($i<count($lines)-1) { $r=$r.','; }
			}
			$r=$r."}";
			echo $r;
		} else {
			echo "Error. Keyfile was not found";
		}
	} else {
		if ((ISSET($_COOKIE['dim'])) && (ISSET($_COOKIE['xid']))) {
			echo "keybase service is ready";
		} else {
			echo "keybase is not ready; retry auth";
		}
	}
} else {
	echo ">>keybase service is not loaded";
}
?>